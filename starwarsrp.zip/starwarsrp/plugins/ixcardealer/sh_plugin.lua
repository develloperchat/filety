PLUGIN.name = "IxCarDealer"
PLUGIN.description = "Plugin for buying cars from a car dealer"
PLUGIN.author = "Lister"

IxCarDealer = IxCarDealer or {}
IxCarDealer.Cars = {
    {
        name = "Tie Fighter",
        description = "Voila ton Tie assassin.",
        model = "models/kingpommes/starwars/tie/fighter.mdl",
        classname = "Chasseur impérial",
        spawnname = "lvs_tie_fighter",
        price = "0",
        spawnpos = Vector(4564.428711, 31.289368, -5404.892578),
        angle = Angle( -0.048870, -179.923340, 0.000000)
    }
}

function PLUGIN:SaveData()
    local data = {}
        for k, v in ipairs(ents.FindByClass("ix_cardealer")) do
            data[#data + 1] =
            {
                pos = v:GetPos(),
                angles = v:GetAngles()
            }
        end

    self:SetData(data)
end

function PLUGIN:LoadData()
    for k, v in ipairs(self:GetData() or {}) do
        local entity = ents.Create("ix_cardealer")
        entity:SetPos(v.pos)
        entity:SetAngles(v.angles)
        entity:Spawn()
    end
end
