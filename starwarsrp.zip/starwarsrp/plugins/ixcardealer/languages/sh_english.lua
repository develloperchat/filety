LANGUAGE = {
	cardealerName = "Car Dealer",
    cardealerDesc = "A Human who selling cars.",
    carRent = "Buy a car",
    carPurchTitle = "Car Rental Confirmation",
    carPurch = "Are you sure you want to buy this car for",
    carName = "Name",
    carDesc = "Description",
    carPrice = "Price",
    carNoMoney = "You don't have enough funds to buy this vehicle!",
    serverRestart = "(After restarting the server, the car will disappear)"
}
