PLUGIN.name = "Voice Overlay"
PLUGIN.author = "FoxxoTrystan"
PLUGIN.desc = "Just voice on information"

if (CLIENT) then
	local VoiceChatTexture = Material("rdv/communications/rdv_microphone.png", "smooth")

	function PLUGIN:HUDPaint()
		localplayer = localplayer or LocalPlayer()

		if (localplayer.ixvoicebox) then
			surface.SetMaterial(VoiceChatTexture)

			surface.SetDrawColor(255, 255, 255)
			
			surface.DrawTexturedRect((ScrW() / 2) - 25, ScrH() - 50, 50, 50)
		end
	end

	function PLUGIN:PlayerStartVoice(client)
		client.ixvoicebox = true

		GM = GM or GAMEMODE
		function GM:PlayerStartVoice(ply)
			return
		end
	end

	function PLUGIN:PlayerEndVoice(client)
		client.ixvoicebox = false
	end
end