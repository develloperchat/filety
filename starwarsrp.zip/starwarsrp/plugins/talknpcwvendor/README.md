# Talking NPCs Plugin
Author: Black Tea za rebel1324


---