// First Craft
local achievement = {
    name = "First Craft",
    description = "Craft your first item, on any crafting station.",
    icon = "minerva/halflife2/icons/lambda.png",
    OnCompleted = function(ply)
    end
}

ix.achievements.Register(achievement)