// hypothermia
local achievement = {
    name = "Hypothermia",
    description = "Get hypothermia.",
    icon = "minerva/halflife2/icons/lambda.png",
    OnCompleted = function(ply)
    end
}

ix.achievements.Register(achievement)

// hyperthermia
achievement = {
    name = "Hyperthermia",
    description = "Get hyperthermia.",
    icon = "minerva/halflife2/icons/lambda.png",
    OnCompleted = function(ply)
    end
}

ix.achievements.Register(achievement)