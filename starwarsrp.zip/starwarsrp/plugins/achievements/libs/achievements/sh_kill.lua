--[[
Server Name: [TY-PROJECT] Empire | Serious Roleplay | Helix
Server IP:   162.19.95.90:20004
File Path:   gamemodes/starwarsrp/plugins/achievements/libs/achievements/sh_kill.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

// Kill Ah!LoUx
local achievement = {
    name = "Vous avez tué le patron!",
    description = "Vous devez tuer Kosmos le premier qui freekill = ban : - )",
    icon = "icon16/gun.png",
    OnCompleted = function(ply)
    end
}

ix.achievements.Register(achievement)

// Kill a player with a headshot
achievement = {
    name = "Headshot!",
    description = "Kill a player with a headshot.",
    icon = "icon16/arrow_in.png",
    OnCompleted = function(ply)
    end
}

ix.achievements.Register(achievement)

// Kill a player with full health
achievement = {
    name = "One Shot, One Kill",
    description = "Kill a player with full health.",
    icon = "icon16/heart_delete.png",
    OnCompleted = function(ply)
    end
}

ix.achievements.Register(achievement)