--[[
Server Name: [TY-PROJECT] Empire | Serious Roleplay | Helix
Server IP:   162.19.95.90:20004
File Path:   gamemodes/starwarsrp/plugins/sh_removebusiness.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

PLUGIN.name = "Remove Business Menu"
PLUGIN.author = "Masco"
PLUGIN.description = "Disable Business menu"

function PLUGIN:BuildBusinessMenu()
  return false
end