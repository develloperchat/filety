--[[
Server Name: [TY-PROJECT] Empire | Serious Roleplay | Helix
Server IP:   162.19.95.90:20004
File Path:   gamemodes/starwarsrp/plugins/waypoints/languages/sh_english.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]


LANGUAGE = {
	cmdWaypointAdd = "Add a waypoint where you are looking.",
	cmdWaypointAddND = "Add a waypoint with no distance marking where you are looking.",
	cmdWaypointUpdate = "Update an existing waypoint closest to where you are looking.",

	cmdWaypointRemove = "Remove an existing waypoint closest to where you are looking.",
	cmdWaypointRemoveAll = "Remove all current waypoints.",

	addedWaypoint = "You have added a waypoint.",
	updatedWaypoint = "You have updated a waypoint.",

	removedWaypoint = "You have removed a waypoint.",
	removedAllWaypoints = "You have removed all waypoints.",

	cannotAddWaypoints = "You cannot add waypoints.",
	cannotRemoveWaypoints = "You cannot remove waypoints.",
	invalidWaypointColor = "'%s' is not a valid color! Use one of these instead:\n%s",

	noWaypointsToRemove = "There are no waypoints that you can remove.",
	noWaypointsNearToRemove = "There are no waypoints that you can remove near where you are looking.",
	noWaypointsToUpdate = "There are no waypoints you can update.",
	noWaypointsNearToUpdate = "There are no waypoints you can update near where you are looking.",

	noWaypointsSet = "There are no waypoints set."
}
