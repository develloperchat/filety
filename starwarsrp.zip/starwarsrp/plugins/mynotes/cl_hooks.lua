--[[
Server Name: [TY-PROJECT] Empire | Serious Roleplay | Helix
Server IP:   162.19.95.90:20004
File Path:   gamemodes/starwarsrp/plugins/mynotes/cl_hooks.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]


local PLUGIN = PLUGIN

net.Receive("ixEditMyNotes", function(length)
	if (PLUGIN.notesPanel and IsValid(PLUGIN.notesPanel)) then
		PLUGIN.notesPanel:Close()
	end

	local text = net.ReadString()

	if (isstring(text)) then
		PLUGIN.notesPanel = vgui.Create("ixMyNotes")
		PLUGIN.notesPanel:Populate(text)
	end
end)

net.Receive("ixCloseMyNotes", function(length)
	local status = net.ReadUInt(6)

	if (isnumber(status) and status > 0) then
		ix.util.NotifyLocalized("mynotesCooldown", status)
	elseif (IsValid(PLUGIN.panel)) then
		PLUGIN.panel:Close()
	end
end)
