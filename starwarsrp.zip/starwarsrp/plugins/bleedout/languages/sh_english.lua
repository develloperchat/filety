LANGUAGE = {
	cmdAdminRevive = "Revive a player who is in a bleedout state.",
	bledOut = "You have bled out!",
	bleedingOut = "You are bleeding out...",
	bleedingOutLong = "You are bleeding out! Type /acceptdeath to accept your death or wait to be stabilized. If you are not stabilized in time, you will bleed out.",
	cmdAcceptDeath = "Accept your death.",
	charBleedOut = "They appear to be bleeding out!",
	deathAccepted = "You have accepted your death.",
	finishedOff = "You have been executed.",
	stabilized = "You have been stabilized, but are still severely injured.",
	stabilizing = "Stabilizing..."
}
