ix.config.Add("BleedoutTime", 60, "Time in seconds to revive a player before bleed out.", nil, {
	category = "Bleedout",
    data = {min = 1, max = 600}
})
