LANGUAGE = {
    npcSpawner = "NPC Spawner",
    optNpcSpawnerShowSpheres = "Show NPC Spawner spheres in observer",
    optNpcSpawnerShowSpawnedNpcs = "Show spawned NPCs in observer",

    npcSpawnerEdit = "Edit NPC Spawner",
    npcSpawnerManager = "NPC Spawner Manager",
    npcSpawnerPools = "NPC Spawner Pools",
    npcSpawnerPoolsEditor = "NPC Spawner Pools Manager",

    npcSpawnerEnabled = "Enabled",
    npcSpawnerNPCClass = "NPC Class",
    npcSpawnerNPCRadius = "Spawn Radius",
    npcSpawnerPlayerRadius = "Player Deactivation Radius",
    npcSpawnerMaxNPCs = "Max NPCs",
    npcSpawnerSpawnInterval = "Spawn Interval",
    npcSpawnerSpawnAmount = "Amount to Spawn",
    npcSpawnerSaveChanges = "Save Changes",

    npcSpawnerLog = "%s has modified a spawner. Changes: \n%s"
}