local PLUGIN = PLUGIN
PLUGIN.name = "Helios Outfits"
PLUGIN.author = "Helios"
PLUGIN.desc = "Fixes some issues with Helix's builtin outfit system."