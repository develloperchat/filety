ITEM.name = "hOutfit"
ITEM.description = "A Better Outfit Base."
ITEM.category = "Outfit"
ITEM.model = "models/Gibs/HGIBS.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.outfitCategory = "model"
ITEM.pacData = {}
ITEM.flag = "v"

--[[
-- This will change a player's skin after changing the model. Keep in mind it starts at 0.
ITEM.newSkin = 1
-- This will change a certain part of the model.
ITEM.replacements = {"group01", "group02"}
-- This will change the player's model completely.
ITEM.replacements = "models/manhack.mdl"
-- This will have multiple replacements.
ITEM.replacements = {
	{"male", "female"},
	{"group01", "group02"}
}
-- This will apply body groups.
ITEM.bodyGroups = {
	["blade"] = 1,
	["bladeblur"] = 1
}
]]--

-- Inventory drawing
if (CLIENT) then
	function ITEM:PaintOver(item, w, h)
		if (item:GetData("equip")) then
			surface.SetDrawColor(110, 255, 110, 100)
			surface.DrawRect(w - 14, h - 14, 8, 8)
		end
	end

	function ITEM:PopulateTooltip(tooltip)
		if self:GetData("equip") then
			local name = tooltip:GetRow("name")
			name:SetBackgroundColor(derma.GetColor("Success", tooltip))
		end

		if self.maxArmor then
			local panel = tooltip:AddRowAfter("name", "armor")
			panel:SetBackgroundColor(derma.GetColor("Warning", tooltip))
			panel:SetText("Armor: " .. (self:GetData("equip", false) && LocalPlayer():Armor() || self:GetData("armor", self.maxArmor)))
			panel:SizeToContents()
		end
	end
end

function ITEM:RemoveOutfit(client)
	local character = client:GetCharacter()

	self:SetData("equip", false)

	if self.maxArmor then
		self:SetData('armor', math.Clamp(client:Armor(), 0, self.maxArmor))
		client:SetArmor(0)
	end

	if (character:GetData("oldModel" .. self.outfitCategory)) then
		character:SetModel(character:GetData("oldModel" .. self.outfitCategory))
		character:SetData("oldModel" .. self.outfitCategory, nil)
	end

	if (self.newSkin) then
		if (character:GetData("oldSkin" .. self.outfitCategory)) then
			client:SetSkin(character:GetData("oldSkin" .. self.outfitCategory))
			character:SetData("oldSkin" .. self.outfitCategory, nil)
			character:SetData("skin", client:GetSkin())
		else
			client:SetSkin(0)
		end
	end

	for k, _ in pairs(self.bodyGroups or {}) do
		local index = client:FindBodygroupByName(k)

		if (index > -1) then
			client:SetBodygroup(index, 0)

			local groups = character:GetData("groups", {})

			if (groups[index]) then
				groups[index] = nil
				character:SetData("groups", groups)
			end
		end
	end

	-- restore the original bodygroups
	if (character:GetData("oldGroups" .. self.outfitCategory)) then
		for k, v in pairs(character:GetData("oldGroups" .. self.outfitCategory, {})) do
			client:SetBodygroup(k, v)
		end

		character:SetData("groups", character:GetData("oldGroups" .. self.outfitCategory, {}))
		character:GetData("oldGroups" .. self.outfitCategory, nil)
	end

	if (self.attribBoosts) then
		for k, _ in pairs(self.attribBoosts) do
			character:RemoveBoost(self.uniqueID, k)
		end
	end

	for k, _ in pairs(self:GetData("outfitAttachments", {})) do
		self:RemoveAttachment(k, client)
	end

	self:OnUnequipped()
end

-- makes another outfit depend on this outfit in terms of requiring this item to be equipped in order to equip the attachment
-- also unequips the attachment if this item is dropped
function ITEM:AddAttachment(id)
	local attachments = self:GetData("outfitAttachments", {})
	attachments[id] = true

	self:SetData("outfitAttachments", attachments)
end

function ITEM:RemoveAttachment(id, client)
	local item = ix.item.instances[id]
	local attachments = self:GetData("outfitAttachments", {})

	if (item and attachments[id]) then
		item:OnDetached(client)
	end

	attachments[id] = nil
	self:SetData("outfitAttachments", attachments)
end

ITEM:Hook("drop", function(item)
	if (item:GetData("equip")) then
		item:RemoveOutfit(item:GetOwner())
	end
end)

ITEM.functions.EquipUn = { -- sorry, for name order.
	name = "Unequip",
	tip = "equipTip",
	icon = "icon16/cross.png",
	OnRun = function(item)
		item:RemoveOutfit(item.player)
		return false
	end,
	OnCanRun = function(item)
		local client = item.player

		return !IsValid(item.entity) and IsValid(client) and item:GetData("equip") == true and
			hook.Run("CanPlayerUnequipItem", client, item) != false and item.invID == client:GetCharacter():GetInventory():GetID()
	end
}

ITEM.functions.Equip = {
	name = "Equip",
	tip = "equipTip",
	icon = "icon16/tick.png",
	OnRun = function(item)
		local client = item.player
		local char = client:GetCharacter()
		local items = char:GetInventory():GetItems()

		for _, v in pairs(items) do
			if (v.id != item.id) then
				local itemTable = ix.item.instances[v.id]

				if (itemTable.pacData and v.outfitCategory == item.outfitCategory and itemTable:GetData("equip")) then
					client:NotifyLocalized(item.equippedNotify or "outfitAlreadyEquipped")
					return false
				end
			end
		end

		item:SetData("equip", true)

		if (item.maxArmor) then
			client:SetArmor(item:GetData("armor", item.maxArmor))
		end

		local currentheadgroup = item.player:FindBodygroupByName("Head")
		if (item.keepHead and currentheadgroup > -1) then
			currentheadgroup = item.player:GetBodygroup(currentheadgroup)
		end

		if (item.replacement or item.replacements) then
			local Selected = item.replacement or item.replacements
			char:SetData("oldModel" .. item.outfitCategory, char:GetData("oldModel" .. item.outfitCategory, item.player:GetModel()))
			if (item.CustomReplacements and istable(item.CustomReplacements)) then
				for i,v in ipairs(item.CustomReplacements) do
					if v[1] == item.player:GetModel() then
						Selected = v[2]
						break
					end
				end
			end
			char:SetModel(Selected)
		end

		if (item.newSkin) then
			char:SetData("oldSkin" .. item.outfitCategory, item.player:GetSkin())
			char:SetData("skin", item.newSkin)

			item.player:SetSkin(item.newSkin)
		end

		local groups = char:GetData("groups", {})

		if (!table.IsEmpty(groups)) then
			char:SetData("oldGroups" .. item.outfitCategory, groups)

			if !item.noResetBodyGroups then
				client:ResetBodygroups()
			end
		end

		if (item.keepHead and currentheadgroup > -1) then
			local headgroup = item.player:FindBodygroupByName("Head")
			if (headgroup > -1) then
				item.player:SetBodygroup(headgroup, currentheadgroup)
			end
		end

		if (item.bodyGroups) then
			groups = {}

			for k, value in pairs(item.bodyGroups) do
				local index = item.player:FindBodygroupByName(k)

				if (index > -1) then
					groups[index] = value
				end
			end

			local newGroups = char:GetData("groups", {})

			for index, value in pairs(groups) do
				newGroups[index] = value
				item.player:SetBodygroup(index, value)
			end

			if (!table.IsEmpty(newGroups)) then
				char:SetData("groups", newGroups)
			end
		end

		if (item.attribBoosts) then
			for k, v in pairs(item.attribBoosts) do
				char:AddBoost(item.uniqueID, k, v)
			end
		end

		item:OnEquipped()
		return false
	end,
	OnCanRun = function(item)
		local client = item.player

		if item.allowedModels and !table.HasValue(item.allowedModels, client:GetModel()) then return false end
		return !IsValid(item.entity) and IsValid(client) and item:GetData("equip") != true and item:CanEquipOutfit() and
			hook.Run("CanPlayerEquipItem", client, item) != false and item.invID == client:GetCharacter():GetInventory():GetID()
	end
}

ITEM.functions.Repair = {
	name = "Repair",
	tip = "repairTip",
	icon = "icon16/wrench.png",
	OnRun = function(item)
		item:Repair(item.player)
		return false
	end,
	OnCanRun = function(item)
		local client = item.player
		return (item.maxArmor != nil && item:GetData("equip") == false && !IsValid(item.entity) && IsValid(client) && client:GetCharacter():GetInventory():HasItem("tool_repair") && item:GetData("armor") < item.maxArmor)
	end
}

function ITEM:CanTransfer(oldInventory, newInventory)
	if (newInventory and self:GetData("equip")) then
		return false
	end

	return true
end

function ITEM:OnRemoved()
	if (self.invID != 0 and self:GetData("equip")) then
		self.player = self:GetOwner()
			self:RemoveOutfit(self.player)
		self.player = nil
	end
end

function ITEM:OnInstanced()
	if (self.maxArmor) then
		self:SetData("armor", self.maxArmor)
	end
end

function ITEM:OnLoadout()
	if (self.maxArmor && self:GetData("equip")) then
		self.player:SetArmor(self:GetData("armor", self.maxArmor))
	end
end

function ITEM:OnSave()
	if (self.maxArmor && self:GetData("equip")) then
		self:SetData("armor", math.Clamp(self.player:Armor(), 0, self.maxArmor))
	end
end

function ITEM:OnEquipped()
end

function ITEM:OnUnequipped()
end

function ITEM:CanEquipOutfit()
	if (self.maxArmor) then
		local outfits = self.player:GetCharacter():GetInventory():GetItemsByBase("base_houtfit", true)
		for _, v in next, outfits do
			if (v:GetData("equip") && v.maxArmor) then
				return false
			end
		end
	end

	return true
end

function ITEM:Repair(client, amount)
	amount = amount || self.maxArmor
	local repairItem = client:GetCharacter():GetInventory():HasItem("tool_repair")

	if (repairItem) then
		self:SetData("armor", math.Clamp(self:GetData("armor") + amount, 0, self.maxArmor))
		repairItem:Remove()
	end
end
