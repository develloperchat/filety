ITEM.name = "Kit de reparation"
ITEM.description = "Repair Kit."
ITEM.model = Model("models/props/starwars/weapons/repairkit.mdl")
ITEM.category = "Clothing"
ITEM.flag = "v"