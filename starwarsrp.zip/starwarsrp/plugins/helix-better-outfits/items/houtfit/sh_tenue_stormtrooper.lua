ITEM.name = "Uniforme de Stormtrooper"
ITEM.description = "Uniforme reglementaire des Stormtroopers."
ITEM.model = "models/nada/props/stormtrooperhelmet.mdl"
ITEM.category = "Clothing"
ITEM.outfitCategory = "Tenue"
ITEM.maxArmor = 100

ITEM.height = 2
ITEM.width = 2

ITEM.newSkin = 0

ITEM.replacements = "models/nada/RogueOneTK.mdl"