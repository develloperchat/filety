
PLUGIN.name = "Writing"
PLUGIN.description = "Adds purchasable items which players can write/edit."
PLUGIN.author = "`impulse"
PLUGIN.maxLength = 512

ix.util.Include("sv_hooks.lua")
ix.util.Include("cl_hooks.lua")
