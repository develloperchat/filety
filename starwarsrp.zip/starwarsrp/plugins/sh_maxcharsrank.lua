--[[
Server Name: [TY-PROJECT] Empire | Serious Roleplay | Helix
Server IP:   162.19.95.90:20004
File Path:   gamemodes/starwarsrp/plugins/sh_maxcharsrank.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

PLUGIN.name = "Rank based max chars"
PLUGIN.author = "Lechu2375"
PLUGIN.description = "Maximal characters are based on player group."
PLUGIN.license =  "MIT not for use on Kaktusownia opensource.org/licenses/MIT"

local pluginTable = {}
local function addRanked(group,amount)
    if !isstring(group)  then
        Error("[MaxCharsPlugin]Group should be number!")
    end
    if !isnumber(amount) then
        error("[MaxCharsPlugin]Amount should be number!")
    end
    pluginTable[group] = amount
end

function PLUGIN:GetMaxPlayerCharacter(client)
    if pluginTable[client:GetUserGroup()] then
        return pluginTable[client:GetUserGroup()]
    end
end

addRanked("superadmin", 5)
addRanked("admin", 5)
addRanked("Adminitrateur", 5)
addRanked("Staff", 5)
addRanked("Animateur", 5)
addRanked("VIP", 2)
addRanked("user", 1)