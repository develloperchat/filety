--[[
Server Name: [TY-PROJECT] Empire | Serious Roleplay | Helix
Server IP:   162.19.95.90:20004
File Path:   gamemodes/starwarsrp/plugins/tfa_support/sh_tfa_ammo.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]


--
-- Copyright (C) 2019 Taxin2012
--
-- Licensed under the Apache License, Version 2.0 (the "License");
-- you may not use this file except in compliance with the License.
-- You may obtain a copy of the License at
--
--     http://www.apache.org/licenses/LICENSE-2.0
--
-- Unless required by applicable law or agreed to in writing, software
-- distributed under the License is distributed on an "AS IS" BASIS,
-- WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
-- See the License for the specific language governing permissions and
-- limitations under the License.
--



--	Writed by Taxin2012
--	https://steamcommunity.com/id/Taxin2012/



-- PLUGIN.AmmoData[ "assault" ] = {
-- 	Name = "Ammo for assault rifles",
-- 	Amount = 30,
-- 	Price = 2000,
-- 	Model = "models/Items/BoxSRounds.mdl",
-- 	Width = 1,
-- 	Height = 1
-- }

PLUGIN.AmmoData[ "ar2" ] = {
	Name = "Cartouche de plasma",
	Amount = 50,
	Price = 0,
	Model = "models/Items/battery.mdl",
	Width = 1,
	Height = 1
}

PLUGIN.AmmoData[ "RPG_Round" ] = {
	Name = "Roquette",
	Amount = 1,
	Price = 0,
	Model = "models/sw_battlefront/weapons/rocketprojectile.mdl",
	Width = 1,
	Height = 1
}

