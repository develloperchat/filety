--[[
Server Name: [TY-PROJECT] Empire | Serious Roleplay | Helix
Server IP:   162.19.95.90:20004
File Path:   gamemodes/starwarsrp/plugins/tfa_support/sh_tfa_weps.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]


--
-- Copyright (C) 2020 Taxin2012
--
-- Licensed under the Apache License, Version 2.0 (the "License");
-- you may not use this file except in compliance with the License.
-- You may obtain a copy of the License at
--
--     http://www.apache.org/licenses/LICENSE-2.0
--
-- Unless required by applicable law or agreed to in writing, software
-- distributed under the License is distributed on an "AS IS" BASIS,
-- WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
-- See the License for the specific language governing permissions and
-- limitations under the License.
--



--	Writed by Taxin2012
--	https://steamcommunity.com/id/Taxin2012/



-- PLUGIN.GunData[ "tfa_ins2_ak74m" ] = {
-- 	--Weapon can be Blacklisted and item will be not auto-generated
-- 	BlackList = false,
	
-- 	Slot = "primary",
-- 	Model = "path_to_model_of_item",
-- 	iconCam = {
-- 		tpos = Vector( 0, 0, 0 ),
-- 		tang = Angle( 0, 0, 0 ),
-- 		tfov = 0
-- 	},
-- 	Width = 4,
-- 	Height = 2,
-- 	Weight = 3,
-- 	Price = 2000,
	
-- 	--Weapon Parameters
-- 	--Prim == Primary
-- 	Prim = {
-- 		Ammo = "assault",
-- 		Damage = 31,
-- 		KickUp = 0.4,
-- 		KickDown = 0.4,
-- 		KickHorizontal = 0.35,
-- 		Spread = .021,
-- 		IronAccuracy = .01
-- 	},
	
-- 	--Sec == Secondary
-- 	Sec = {}
-- }

PLUGIN.GunData[ "rw_sw_e11" ] = {
	BlackList = false,
	bDropOnDeath = true,
	Model = "models/sw_battlefront/weapons/e11_blaster_rifle.mdl",

	Slot = "primary",
	Width = 3,
	Height = 2
}

PLUGIN.GunData[ "rw_sw_scoutblaster" ] = {
	BlackList = false,
	bDropOnDeath = true,
	Model = "models/weapons/synbf3/w_scoutblaster.mdl",

	Slot = "secondary",
	Width = 2,
	Height = 2
}

PLUGIN.GunData[ "rw_sw_trd_e11" ] = {
	BlackList = false,
	bDropOnDeath = true,
	Model = "models/sw_battlefront/weapons/e11_blaster_rifle.mdl",
	
	Slot = "primary",
	Width = 3,
	Height = 2
}

PLUGIN.GunData[ "rw_sw_tl50" ] = {
	BlackList = false,
	bDropOnDeath = true,
	Model = "models/sw_battlefront/weapons/tl50_repeater.mdl",
	
	Slot = "primary",
	Width = 4,
	Height = 2

}

PLUGIN.GunData[ "rw_sw_dlt19" ] = {
	BlackList = false,
	bDropOnDeath = true,
	Model = "models/sw_battlefront/weapons/dlt19_heavy_rifle.mdl",
	
	Slot = "primary",
	Width = 5,
	Height = 2
}

PLUGIN.GunData[ "rw_sw_trd_dlt19" ] = {
	BlackList = false,
	bDropOnDeath = true,
	Model = "models/sw_battlefront/weapons/dlt19_heavy_rifle.mdl",
	
	Slot = "primary",
	Width = 5,
	Height = 2
}

PLUGIN.GunData[ "rw_sw_e11d" ] = {
	BlackList = false,
	bDropOnDeath = true,
	Model = "models/banks/sw_battlefront/weapons/e11d_blaster_carbine.mdl",
	
	Slot = "primary",
	Width = 4,
	Height = 2
}

PLUGIN.GunData[ "rw_sw_t21" ] = {
	BlackList = false,
	bDropOnDeath = true,
	Model = "models/weapons/synbf3/w_t21.mdl",
	
	Slot = "primary",
	Width = 5,
	Height = 2
}

PLUGIN.GunData[ "rw_sw_a280c" ] = {
	BlackList = true
}

PLUGIN.GunData[ "rw_sw_a280cfe" ] = {
	BlackList = false,
	bDropOnDeath = true,
	Model = "models/sw_battlefront/weapons/a280_cfe.mdl",

	Slot = "primary",
	Width = 4,
	Height = 2
}

PLUGIN.GunData[ "rw_sw_dc15a_purge" ] = {
	BlackList = false,
	bDropOnDeath = true,
	Model = "models/megarex/dc15a.mdl",
	
	Slot = "primary",
	Width = 4,
	Height = 2
}

PLUGIN.GunData[ "rw_sw_a280c" ] = {
	BlackList = false,
	bDropOnDeath = true,
	Model = "models/sw_battlefront/weapons/a280c_noscope2.mdl",
	
	Slot = "primary",
	Width = 4,
	Height = 2
}

PLUGIN.GunData[ "rw_sw_dc17_purge" ] = {
	BlackList = false,
	bDropOnDeath = true,
	Model = "models/sw_battlefront/weapons/dc17_blaster.mdl",
		
	Slot = "secondary",
	Width = 2,
	Height = 2
}

PLUGIN.GunData[ "rw_sw_dl44" ] = {
	BlackList = false,
	bDropOnDeath = true,
	Model = "models/sw_battlefront/weapons/dl44_pistol.mdl",
		
	Slot = "secondary",
	Width = 2,
	Height = 2
}

PLUGIN.GunData[ "rw_sw_e60r" ] = {
	BlackList = false,
	bDropOnDeath = true,
	Model = "models/cs574/weapons/e60r.mdl",
	
	Slot = "primary",
	Width = 5,
	Height = 2
}

PLUGIN.GunData[ "rw_sw_stun_e11" ] = {
	BlackList = false,
	bDropOnDeath = true,
	Model = "models/sw_battlefront/weapons/e11_blaster_rifle.mdl",
	
	Slot = "tool",
	Width = 2,
	Height = 2
}

PLUGIN.GunData[ "rw_sw_e11_noscope" ] = {
	BlackList = false,
	bDropOnDeath = true,
	Model = "models/sw_battlefront/weapons/e11_blaster_rifle.mdl",
	
	Slot = "primary",
	Width = 3,
	Height = 2
}

PLUGIN.GunData[ "rw_sw_rk3" ] = {
	BlackList = false,
	bDropOnDeath = true,
	Model = "models/sw_battlefront/weapons/rk3_pistol.mdl",
	
	Slot = "secondary",
	Width = 2,
	Height = 2
}

PLUGIN.GunData[ "rw_sw_rt97c" ] = {
	BlackList = true,
}

PLUGIN.GunData[ "rw_sw_dh17a" ] = {
	BlackList = true,
}

PLUGIN.GunData[ "rw_sw_dh17" ] = {
	BlackList = false,
	bDropOnDeath = true,
	
	Slot = "secondary",
	Width = 2,
	Height = 2
}

PLUGIN.GunData[ "rw_sw_a280" ] = {
	BlackList = false,
	bDropOnDeath = true,
	
	Slot = "primary",
	Width = 4,
	Height = 2
}

PLUGIN.GunData[ "rw_sw_hh12" ] = {
	BlackList = false,
	bDropOnDeath = true,
	
	Slot = "primary",
	Width = 5,
	Height = 2
}

PLUGIN.GunData[ "rw_sw_hh15" ] = {
	BlackList = false,
	bDropOnDeath = true,
	
	Slot = "primary",
	Width = 5,
	Height = 2
}

PLUGIN.GunData[ "rw_sw_pinglauncher" ] = {
	BlackList = false,
	bDropOnDeath = true,
	
	Slot = "primary",
	Width = 3,
	Height = 3
}

PLUGIN.GunData[ "rw_sw_plx1" ] = {
	BlackList = false,
	bDropOnDeath = true,
	
	Slot = "primary",
	Width = 5,
	Height = 2
}

PLUGIN.GunData[ "rw_sw_rps6" ] = {
	BlackList = false,
	bDropOnDeath = true,
	
	Slot = "primary",
	Width = 5,
	Height = 2
}

PLUGIN.GunData[ "rw_sw_se14r" ] = {
	BlackList = false,
	bDropOnDeath = true,
	
	Slot = "primary",
	Width = 2,
	Height = 2
}

PLUGIN.GunData[ "rw_sw_smartlauncher" ] = {
	BlackList = false,
	bDropOnDeath = true,
	
	Slot = "primary",
	Width = 5,
	Height = 2
}

PLUGIN.GunData[ "rw_sw_z6i" ] = {
	BlackList = false,
	bDropOnDeath = true,
	Slot = "primary",
	Width = 5,
	Height = 3
}

PLUGIN.GunData[ "rw_sw_e10" ] = {
	BlackList = false,
	bDropOnDeath = true,
	
	Slot = "primary",
	Width = 3,
	Height = 2
}

PLUGIN.GunData[ "rw_sw_e11s" ] = {
	BlackList = false,
	bDropOnDeath = true,
	
	Slot = "primary",
	Width = 5,
	Height = 2
}

PLUGIN.GunData[ "rw_sw_tl40" ] = {
	BlackList = false,
	bDropOnDeath = true,
	
	Slot = "primary",
	Width = 4,
	Height = 2
}

PLUGIN.GunData[ "rw_sw_dc15s_purge" ] = {
	BlackList = false,
	bDropOnDeath = true,
	
	Slot = "primary",
	Width = 4,
	Height = 2
}

PLUGIN.GunData[ "rw_sw_dlt19x" ] = {
	BlackList = false,
	bDropOnDeath = true,
	
	Slot = "primary",
	Width = 5,
	Height = 2
}

PLUGIN.GunData[ "rw_sw_nade_bacta" ] = {
	BlackList = true
}

PLUGIN.GunData[ "rw_sw_nade_dioxis" ] = {
	BlackList = true
}


PLUGIN.GunData[ "rw_sw_nade_flash" ] = {
	BlackList = true
}

PLUGIN.GunData[ "rw_sw_nade_impact" ] = {
	BlackList = true
}

PLUGIN.GunData[ "rw_sw_nade_stun" ] = {
	BlackList = true
}

PLUGIN.GunData[ "rw_sw_nade_smoke" ] = {
    BlackList = true
}

PLUGIN.GunData[ "rw_sw_nade_training" ] = {
    BlackList = true
}

PLUGIN.GunData[ "rw_sw_nade_thermal" ] = {
    BlackList = true
}

PLUGIN.GunData[ "rw_sw_nade_incendiary" ] = {
	BlackList = true
}

PLUGIN.GunData[ "rw_sw_trd_e11_noscope" ] = {
	BlackList = true
}

PLUGIN.GunData[ "rw_sw_t7" ] = {
	BlackList = false,
	bDropOnDeath = true,
	
	Slot = "primary",
	Width = 5,
	Height = 2
}

PLUGIN.GunData[ "rw_sw_dual_dh17a" ] = {
	BlackList = true,
}

PLUGIN.GunData[ "rw_sw_dlt19s" ] = {
	BlackList = false,
	bDropOnDeath = true,
	
	Slot = "primary",
	Width = 5,
	Height = 2
}

PLUGIN.GunData[ "rw_sw_dual_e11" ] = {
	BlackList = true
}

PLUGIN.GunData[ "rw_sw_dual_d" ] = {
	BlackList = false,
	bDropOnDeath = true,
	
	Slot = "primary",
	Width = 5,
	Height = 2
}

PLUGIN.GunData[ "rw_sw_dual_defender" ] = {
	BlackList = true
}

PLUGIN.GunData[ "rw_sw_dual_dl44" ] = {
	BlackList = true
}

PLUGIN.GunData[ "rw_sw_dual_dt12" ] = {
	BlackList = true
}

PLUGIN.GunData[ "rw_sw_dual_ib94" ] = {
	BlackList = false,
	bDropOnDeath = true,
	
	Slot = "primary",
	Width = 5,
	Height = 2
}

PLUGIN.GunData[ "rw_sw_dual_ll30" ] = {
	BlackList = true
}

PLUGIN.GunData[ "rw_sw_dual_westar34" ] = {
	BlackList = true
}

PLUGIN.GunData[ "rw_sw_dual_westar35" ] = {
	BlackList = true
}

PLUGIN.GunData[ "rw_sw_s5c" ] = {
	BlackList = true
}

PLUGIN.GunData[ "rw_sw_ee3a" ] = {
	BlackList = false,
	bDropOnDeath = true,
	
	Slot = "primary",
	Width = 5,
	Height = 2
}

PLUGIN.GunData[ "rw_sw_cr2" ] = {
	BlackList = false,
	bDropOnDeath = true,
	Model = "models/sw_battlefront/weapons/cr2_pistol.mdl",
    
	Slot = "primary",
	Width = 2,
	Height = 2
}