--[[
Server Name: [TY-PROJECT] Empire | Serious Roleplay | Helix
Server IP:   162.19.95.90:20004
File Path:   gamemodes/starwarsrp/plugins/item_collide.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]


local PLUGIN = PLUGIN
PLUGIN.name = "Item collide fixer"
PLUGIN.author = "Bilwin"
PLUGIN.description = "Stop killing server through item collisions bounds"
PLUGIN.BlockedCollideEntities = {}
PLUGIN.BlockedCollideEntities['ix_item'] = true
PLUGIN.BlockedCollideEntities['ix_money'] = true
PLUGIN.BlockedCollideEntities['ix_shipment'] = true

function PLUGIN:OnItemSpawned(ent)
    ent:SetCustomCollisionCheck(true)
end

function PLUGIN:OnMoneySpawned(ent)
    ent:SetCustomCollisionCheck(true)
end

function PLUGIN:OnShipmentSpawned(ent)
    ent:SetCustomCollisionCheck(true)
end

function PLUGIN:ShouldCollide(ent1, ent2)
    if self.BlockedCollideEntities[ent1:GetClass()] && self.BlockedCollideEntities[ent2:GetClass()] then return false end
end