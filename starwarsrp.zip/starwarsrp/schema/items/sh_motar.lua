ITEM.name = "Mortier"
ITEM.description = ""
ITEM.class = "mortar_constructor"
ITEM.weaponCategory = "mortar"
ITEM.weaponCategory = "Weapons"
ITEM.model = "models/dolunity/starwars/mortar.mdl"
ITEM.width = 4
ITEM.height = 4
ITEM.bDropOnDeath = true
ITEM.iconCam = {
	pos = Vector(591.95, 482.33, 354.22),
	ang = Angle(25, 220, 0),
	fov = 3.28
}

ITEM.functions.Placer = { 
	name = "Placer",
	tip = "Placer le mortier.",
	icon = "icon16/user_add.png",
	OnRun = function(item)
		local player = item.player
		player:Give("mortar_constructor")
	end,
}
