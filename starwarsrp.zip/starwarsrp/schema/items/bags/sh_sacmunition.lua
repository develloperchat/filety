ITEM.name = "Pochette à munitions."
ITEM.description = "Un petit sac pour vos munitions."
ITEM.model = Model("models/nada/props/pouch_pile.mdl")
ITEM.width = 2
ITEM.height = 1
ITEM.invWidth = 3
ITEM.invHeight = 1
ITEM.bDropOnDeath = true