ITEM.name = "Sac a dos Médicale"
ITEM.description = "Un sac vous permettant d'avoir plus de place sur vous."
ITEM.model = Model("models/nada/props/backpack_jedha.mdl")
ITEM.width = 4
ITEM.height = 4
ITEM.invWidth = 5
ITEM.invHeight = 5
ITEM.bDropOnDeath = true