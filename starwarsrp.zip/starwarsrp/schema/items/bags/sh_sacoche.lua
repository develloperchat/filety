ITEM.name = "Sacoche"
ITEM.description = "Une sacoche pour votre matériel."
ITEM.model = Model("models/props_c17/BriefCase001a.mdl")
ITEM.width = 2
ITEM.height = 2
ITEM.invWidth = 4
ITEM.invHeight = 2
ITEM.bDropOnDeath = true