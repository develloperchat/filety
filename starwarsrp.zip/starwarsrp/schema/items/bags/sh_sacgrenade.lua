ITEM.name = "Sac au Spécialiste."
ITEM.description = "Un petit sac pour vos grenades et autre Objets."
ITEM.model = Model("models/nada/props/backpack_mortar.mdl")
ITEM.width = 4
ITEM.height = 4
ITEM.invWidth = 5
ITEM.invHeight = 5
ITEM.bDropOnDeath = true