ITEM.name = "Adrénaline"
ITEM.description = "Une drogue pour courrir plus longtemps, pendant quelques temps."
ITEM.model = "models/krieg/galacticempire/props/bacta_syringe.mdl"
ITEM.category = "Consumables"
ITEM.bDropOnDeath = true

ITEM.functions.InjectSelf = {
    name = "Inject",
    OnRun = function(item)
        local ply = item.player

        if not ( IsValid(ply) ) then
            return
        end
        
        if (ply:Team() == FACTION_DROID) then
            return
        end

        local char = ply:GetCharacter()

        if not ( char ) then
            return
        end

        ply:SetAction("Injection...", item.injectTime, function()
            if not ( IsValid(ply) ) then
                return
            end

            if (ply:Team() == FACTION_DROID) then
                return
            end

            if not ( ply:Alive() ) then
                return
            end

            if not ( char ) then
                return
            end

            ix.chat.Send(ply, "me", "utilise de l'".. item.name .. ".")

            char:AddBoost("Endurance", "end", 50)
            char:AddBoost("Stamina", "stm", 50)
            timer.Simple(300, function()
                char:RemoveBoost("Endurance", "end")
                char:RemoveBoost("Stamina", "stm")
            end)

        end)

        return true
    end
}

ITEM.functions.InjectOther = {
    name = "Inject Target",
    OnRun = function(item)
        local ply = item.player
        
        if not ( IsValid(ply) ) then
            return false
        end

        local char = ply:GetCharacter()

        if not ( char ) then
            return false
        end

        local trace = util.TraceLine({
            start = ply:EyePos(),
            endpos = ply:EyePos() + ply:GetAimVector() * 96,
            filter = ply
        })

        local target = trace.Entity

        if not ( IsValid(target) and target:IsPlayer() ) then
            return false
        end

        if (target:Team() == FACTION_DROID) then
            return false
        end

        if not ( ply:GetPos():Distance(target:GetPos()) <= 96 ) then
            return false
        end

        local targetChar = target:GetCharacter()

        if not ( targetChar ) then
            return false
        end

        ply:SetAction("Injection...", item.injectTime, function()
            if not ( IsValid(ply) ) then
                return
            end

            if not ( ply:Alive() ) then
                return
            end

            if not ( IsValid(target) ) then
                return
            end

            if (target:Team() == FACTION_DROID) then
                return
            end

            if not ( target:Alive() ) then
                return
            end

            if not ( targetChar ) then
                return
            end

            ix.chat.Send(ply, "me", "utilise une ".. item.name .. " sur ".. targetChar:GetName())

            targetChar:AddBoost("Endurance", "end", 50)
            targetChar:AddBoost("Stamina", "stm", 50)
            timer.Simple(300, function()
                targetChar:RemoveBoost("Endurance", "end")
                targetChar:RemoveBoost("Stamina", "stm")
            end)
        end)
        return true
    end,
    OnCanRun = function(item)
        local ply = item.player
        
        if not ( IsValid(ply) ) then
            return false
        end

        local char = ply:GetCharacter()

        if not ( char ) then
            return false
        end

        local trace = util.TraceLine({
            start = ply:EyePos(),
            endpos = ply:EyePos() + ply:GetAimVector() * 96,
            filter = ply
        })

        local target = trace.Entity

        if not ( IsValid(target) and target:IsPlayer() ) then
            return false
        end

        if (target:Team() == FACTION_DROID) then
            return false
        end

        if not ( ply:GetPos():Distance(target:GetPos()) <= 100 ) then
            return false
        end

        local targetChar = target:GetCharacter()

        if not ( targetChar ) then
            return false
        end

        return true
    end
}