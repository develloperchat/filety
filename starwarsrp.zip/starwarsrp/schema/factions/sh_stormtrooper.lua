FACTION.name = "Corps des Stormtroopers"
FACTION.description = "Test"
FACTION.color = Color(255, 255, 255)
FACTION.isDefault = false
FACTION.canSeeWaypoints = true
FACTION.weapons = {"bkeycard", "salute", "surrender"}
FACTION.pay = 2
FACTION.payTime = 1800
FACTION.isGloballyRecognized = false
FACTION.models = {
	"models/nada/pms/male/trooper.mdl",
	"models/nada/pms/female/trooper.mdl"
}

FACTION_STORMTROOPER = FACTION.index