CLASS.name = "Stormtrooper"
CLASS.faction = FACTION_STORMTROOPER
CLASS.isDefault = false
CLASS_STORM = CLASS.index